MIT License

Copyright (c) 2024 PowerGPT Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## License Information for Nature Submission

**License Type**: MIT License  
**License Approval**: Approved by Open Source Initiative (OSI)  
**License URL**: https://opensource.org/licenses/MIT  
**Compatibility**: Compatible with academic and commercial use  

### License Features
- ✅ **Open Source**: Free to use, modify, and distribute
- ✅ **Academic Use**: Suitable for research and educational purposes
- ✅ **Commercial Use**: Can be used in commercial applications
- ✅ **Attribution**: Requires copyright notice preservation
- ✅ **Warranty**: No warranty provided (standard for open source)

### Usage Rights
- **Use**: Modify, distribute, and use the software for any purpose
- **Modify**: Create derivative works and modifications
- **Distribute**: Share the software with others
- **Commercial Use**: Use in commercial applications
- **Patent Use**: Use patented technology included in the software

### Requirements
- **Copyright Notice**: Must include the original copyright notice
- **License Text**: Must include the MIT License text
- **No Warranty**: Software is provided "as is" without warranty

### Contact Information
For licensing questions, contact: xiaoqian.jiang@uth.tmc.edu 